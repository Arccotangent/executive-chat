package net.arccotangent.ChatServer;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.BindException;
import java.net.ConnectException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.fourthline.cling.UpnpService;
import org.fourthline.cling.UpnpServiceImpl;
import org.fourthline.cling.model.message.header.STAllHeader;
import org.fourthline.cling.model.meta.LocalDevice;
import org.fourthline.cling.model.meta.RemoteDevice;
import org.fourthline.cling.registry.Registry;
import org.fourthline.cling.registry.RegistryListener;
import org.fourthline.cling.support.igd.PortMappingListener;
import org.fourthline.cling.support.model.PortMapping;

import net.arccotangent.Chat.Main;

public class Server extends Thread {
	
	private static Socket socket;
	private static ServerSocket serverSocket;
	private static UpnpService UPNP_SERVICE = null;
	public static final int SERVER_PORT = 21367;
	private static boolean upnp_open = false;
	
	/*
	private static int countlines(String str)
	{
		String[] lines = str.split("\r\n|\r|\n");
		return  lines.length;
	}
	*/
	
    public static RegistryListener REGISTRY_LISTENER = new RegistryListener() {

        public void remoteDeviceDiscoveryStarted(Registry registry,
                                                 RemoteDevice device) {
        	Main.log.info(
                    "[UPNP/REGISTRY] Discovery started: " + device.getDisplayString()
            );
        }

        public void remoteDeviceDiscoveryFailed(Registry registry,
                                                RemoteDevice device,
                                                Exception ex) {
        	Main.log.err(
                    "[UPNP/REGISTRY] Discovery failed: " + device.getDisplayString() + " => " + ex
            );
        }

        public void remoteDeviceAdded(Registry registry, RemoteDevice device) {
        	Main.log.info(
                    "[UPNP/REGISTRY] Remote device available: " + device.getDisplayString()
            );
        }

        public void remoteDeviceUpdated(Registry registry, RemoteDevice device) {
        	Main.log.info(
                    "[UPNP/REGISTRY] Remote device updated: " + device.getDisplayString()
            );
        }

        public void remoteDeviceRemoved(Registry registry, RemoteDevice device) {
        	Main.log.warn(
                    "[UPNP/REGISTRY] Remote device removed: " + device.getDisplayString()
            );
        }

        public void localDeviceAdded(Registry registry, LocalDevice device) {
        	Main.log.info(
                    "[UPNP/REGISTRY] Local device added: " + device.getDisplayString()
            );
        }

        public void localDeviceRemoved(Registry registry, LocalDevice device) {
        	Main.log.warn(
                    "[UPNP/REGISTRY] Local device removed: " + device.getDisplayString()
            );
        }

        public void beforeShutdown(Registry registry) {
        	Main.log.info(
                    "[UPNP/REGISTRY] Before shutdown, the registry has devices: "
                    + registry.getDevices().size()
            );
        }

        public void afterShutdown() {
        	Main.log.info("[UPNP/REGISTRY] Shutdown of registry complete!");

        }
    };
	
	public static void getLocalIPAddr()
	{
		if (System.getProperty("os.name").contains("Linux"))
		{
			ArrayList<Inet4Address> i4 = new ArrayList<Inet4Address>();
			Enumeration<NetworkInterface> e = null;
			try {
				e = NetworkInterface.getNetworkInterfaces();
			} catch (SocketException e1) {
				e1.printStackTrace();
			}
			while(e.hasMoreElements())
			{
			    NetworkInterface n = (NetworkInterface) e.nextElement();
			    System.out.print(n.getName() + ": ");
			    Enumeration<InetAddress> ee = n.getInetAddresses();
			    while (ee.hasMoreElements())
			    {
			        InetAddress i = (InetAddress) ee.nextElement();
			        if (i instanceof Inet4Address)
			        {
			        	System.out.println(i.getHostAddress());
			        	i4.add((Inet4Address) i);
			        }
			    }
			}
			for (int i = 0; i < i4.size(); i++)
			{
				Inet4Address i4b = i4.get(i);
				if (!i4b.isLoopbackAddress() && !i4b.getHostAddress().startsWith("127."))
				{
					Main.log.info("[LINUX] Found seemingly valid IPv4 address in enumeration: " + i4b.getHostAddress());
					Main.LOCAL_IP_ADDRESS = i4b.getHostAddress();
					return;
				}
			}
			if (Main.LOCAL_IP_ADDRESS.isEmpty())
			{
				try {
					Main.LOCAL_IP_ADDRESS = InetAddress.getLocalHost().getHostAddress();
				} catch (UnknownHostException e1) {
					e1.printStackTrace();
				}
			}
			Main.log.info("[LINUX] IP address detected as: " + Main.LOCAL_IP_ADDRESS);
		}
		else
		{
			try {
				Main.LOCAL_IP_ADDRESS = InetAddress.getLocalHost().getHostAddress();
			} catch (UnknownHostException e) {
				e.printStackTrace();
			}
			Main.log.info("[NON-LINUX] IP address detected as: " + Main.LOCAL_IP_ADDRESS);
		}
	}
	
	public void run()
	{
		System.out.println("[SERVER] Attempting to start server.");
		try
        {
			if (!upnp_open)
				UPNPOpenPorts();
            serverSocket = new ServerSocket(SERVER_PORT);
            //Server is running always. This is done using this while(true) loop
            while(true) 
            {
                //Reading the message from the client
            	Main.log.info("[SERVER] Server started and listening on port " + SERVER_PORT + ", awaiting messages.");
                socket = serverSocket.accept();
                InputStream is = socket.getInputStream();
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);
                int numlines = Integer.parseInt(br.readLine());
                Main.log.info("[SERVER] Message header: " + numlines + " lines in message");
                String message = "";
                for (int i = 0; i < numlines; i++)
                {
                	message = message + br.readLine() + "\n";
                }
                /*
                String msgbuf = br.readLine();
                while (!msgbuf.equals("") && msgbuf != null)
                {
                	message = message + "\n" + msgbuf;
                	msgbuf = br.readLine();
                	System.out.println("Read line from socket stream.");
                }
                */
                //int llindex = message.lastIndexOf('\n');
                //message = message.substring(llindex, message.length());
                final InetAddress srcip = socket.getInetAddress();
                String srcipaddr = srcip.getHostAddress();
                message = "This message comes from IP address: " + srcipaddr + "\n\n" + message;
                if (message.equals("ping"))
                {
                	String returnMessage;
                    returnMessage = "152 Pong";
     
                    //Sending the response back to the client.
                    OutputStream os = socket.getOutputStream();
                    OutputStreamWriter osw = new OutputStreamWriter(os);
                    BufferedWriter bw = new BufferedWriter(osw);
                    bw.write(returnMessage);
                    Main.log.info("Responded to client with pong message: " + returnMessage);
                    bw.flush();
                    bw.close();
                	serverSocket.close();
                    JOptionPane.showMessageDialog(null, "Received ping from " + srcipaddr, "Received Ping Message", JOptionPane.WARNING_MESSAGE);
                    run();
                }
                else
                {
                	//Returning message to client to confirm message received
                    String returnMessage;
                    returnMessage = "160 Message received confirmation";
     
                    //Sending the response back to the client.
                    OutputStream os = socket.getOutputStream();
                    OutputStreamWriter osw = new OutputStreamWriter(os);
                    BufferedWriter bw = new BufferedWriter(osw);
                    bw.write(returnMessage);
                    Main.log.info("[SERVER] Responded to client with acknowledgement message: " + returnMessage);
                    bw.flush();
                    bw.close();
                	serverSocket.close();
                    final JFrame reportDisplayFrame = new JFrame("Received Message!");
            		  reportDisplayFrame.setSize(800, 600);
            		  reportDisplayFrame.getContentPane().setLayout(new FlowLayout());
            		  JTextArea reportDisplayText = new JTextArea(25, 70);
            		  reportDisplayText.setEditable(false);
            		  reportDisplayText.setLineWrap(true);
            		  reportDisplayText.setWrapStyleWord(true);
            		  Font reportDisplayFont = new Font("Source Code Pro", Font.PLAIN, 12);
            		  reportDisplayText.setFont(reportDisplayFont);
            		  int horizontalPolicy = JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS;
            		  int verticalPolicy = JScrollPane.VERTICAL_SCROLLBAR_ALWAYS;
            		  String reportText = "Message received:\n\n" + message;
            		  reportDisplayText.setText(reportText);
            		  JScrollPane finalNumberScroll = new JScrollPane(reportDisplayText, verticalPolicy, horizontalPolicy);
            		  reportDisplayFrame.getContentPane().add(finalNumberScroll);
            		  JButton replyButton = new JButton("Reply to " + srcipaddr);
            		  replyButton.addActionListener( new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									try {
										Client.SendReplyMessage(srcip);
									} catch (UnknownHostException e1) {
										JOptionPane.showMessageDialog(null, "Unknown Host Error", "Error", JOptionPane.ERROR_MESSAGE);
									} catch (NullPointerException e1) {
										JOptionPane.showMessageDialog(null, "No Message Sent!", "No Message Sent!", JOptionPane.ERROR_MESSAGE);
									} catch (ConnectException e1) {
										JOptionPane.showMessageDialog(null, "Error: Unable to connect to server. The connection was refused.", "Connection Refused", JOptionPane.ERROR_MESSAGE);
									}
								}
            				  });
            		  JButton closeButton = new JButton("Close");
            		  closeButton.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									reportDisplayFrame.dispatchEvent(new WindowEvent(reportDisplayFrame, WindowEvent.WINDOW_CLOSING));
								}
            				  });
            		  reportDisplayFrame.getContentPane().add(replyButton);
            		  reportDisplayFrame.getContentPane().add(closeButton);
            		  reportDisplayFrame.setVisible(true);
            		  run();
                }
            }
        }
        catch (Exception e) 
        {
        	if (e instanceof BindException)
        		Main.log.err("[SERVER] Error: A server is already running on this port (" + SERVER_PORT + ").");
        	else if (e instanceof SocketException)
        		Main.log.err("[SERVER] Server closed.");
        	else
        	{
        		Main.log.err("[SERVER] Error: An error occurred during operation. Please send this error to the developers.");
                e.printStackTrace();
        	}
        	Main.chkEnableServer.setSelected(false);
        }
        finally
        {
            try
            {
                socket.close();
            }
            catch(Exception e){}
        }
	}
	
	public void CloseServer()
	{
		Main.log.info_nln("[SERVER] Checking if server is running... ");
		if (!serverSocket.isClosed())
		{
			Main.log.info_ln("running. Shutting down.");
			if (upnp_open)
				UPNPClosePorts();
			try
			{
				serverSocket.close();
			}
			catch (IOException e1)
			{
				e1.printStackTrace();
				JOptionPane.showMessageDialog(null, "Error: IO error occurred while shutting down server.", "Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
			//JOptionPane.showMessageDialog(null, "Server stopped! You will no longer be able to receive messages", "Server Stopped", JOptionPane.WARNING_MESSAGE);
		}
		else
		{
			Main.log.info_ln("not running.");
			//JOptionPane.showMessageDialog(null, "Error: Cannot stop server as there is no server running.", "Server Not Running", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void UPNPOpenPorts()
	{
		PortMapping[] ports = new PortMapping[2];

		Main.log.info("[UPNP] Listing ports to be mapped");
		ports[0] = new PortMapping(SERVER_PORT, Main.LOCAL_IP_ADDRESS, PortMapping.Protocol.TCP, Main.CHAT_VERSION + " TCP");
		ports[1] = new PortMapping(SERVER_PORT, Main.LOCAL_IP_ADDRESS, PortMapping.Protocol.UDP, Main.CHAT_VERSION + " UDP");
		//arr[2] = new PortMapping(port, ip, protocol, description);
		for (int i = 0; i < ports.length; i++)
		{
			Main.log.info("[UPNP/PORTMAPPER] Mapping " + i + ": Port " + ports[i].getExternalPort() + ", Protocol " + ports[i].getProtocol().toString());
		}
		Main.log.info("[UPNP] Initializing UPNP service.");
	    PortMappingListener pml = new PortMappingListener(ports);
	    Main.log.info("[UPNP] Registering port mappings.");
		UPNP_SERVICE = new UpnpServiceImpl(pml);
	    UPNP_SERVICE.getRegistry().addListener(REGISTRY_LISTENER);
	    Main.log.info("[UPNP/REGISTRY] Advertising local services.");
	    UPNP_SERVICE.getRegistry().advertiseLocalDevices();
	    Main.log.info("[UPNP/CONTROL-POINT] Sending search message to all devices and services, devices should respond soon.");
	    Main.log.info("[UPNP/CONTROL-POINT] This function's purpose is to try and find the router, then forward ports through it.");
	    UPNP_SERVICE.getControlPoint().search(new STAllHeader());
	    Main.log.info("[UPNP] It seems that we forwarded ports successfully!");
	    Main.log.warn("[UPNP] If it doesn't work, it should within a matter of seconds. You should've gotten some discovery messages. If no discovery messages are printed, something is wrong.");
	    upnp_open = true;
	}
	
	public void UPNPClosePorts()
	{
		Main.log.info("[UPNP] Shutting down port forwarding service.");
		//Main.log.info("[UPNP/REGISTRY] Disconnecting all remote devices.");
		//UPNP_SERVICE.getRegistry().removeAllRemoteDevices();
		//Main.log.info("[UPNP/REGISTRY] Disconnecting all local devices.");
		//UPNP_SERVICE.getRegistry().removeAllLocalDevices();
		UPNP_SERVICE.shutdown();
		Main.log.info("[UPNP] Port forwarding service shut down.");
		upnp_open = false;
	}
}

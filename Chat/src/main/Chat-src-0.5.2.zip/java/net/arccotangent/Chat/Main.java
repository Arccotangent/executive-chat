package net.arccotangent.Chat;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.SwingConstants;
import javax.swing.JButton;

import net.arccotangent.ChatIP.IP;
import net.arccotangent.ChatServer.Client;
import net.arccotangent.ChatServer.Server;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.net.ConnectException;
import java.net.UnknownHostException;

import javax.swing.JCheckBox;

public class Main extends Thread {

	private JFrame frmChatV;
	public static Server server;
	public static JCheckBox chkEnableServer;
	private static final String HOME_DIR = System.getProperty("user.home");
	public static final String CONTACT_DBDIR = HOME_DIR + "/.arcchatcontacts";
	public static final String CHAT_VERSION = "Chat v0.5.2";
	public static String LOCAL_IP_ADDRESS = "";
	public static final ChatLogger log = new ChatLogger();
	public static final boolean debug = false;
	//TODO add ability to set signature in v0.6
	//TODO add group chat functionality in v0.6
	
	public static final String getHomeDir()
	{
		return HOME_DIR;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		Main.log.info("[CORE] Initializing " + CHAT_VERSION);
		Main.log.info("[CORE] Operating system: " + System.getProperty("os.name"));
		Server.getLocalIPAddr();
		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run()
			{
				//Run this code on shutdown
				Main.log.info("[SHUTDOWN] Shutting down " + CHAT_VERSION);
				server.CloseServer();
				Main.log.info("[SHUTDOWN] Bye!");
			}
		});
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main window = new Main();
					window.frmChatV.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		Main.log.info_nln("[CORE] Checking for contact database... ");
		File basedir = new File(CONTACT_DBDIR);
		if (basedir.exists())
		{
			Main.log.info_ln("found!");
		}
		else
		{
			Main.log.info_ln("not found! Creating.");
			boolean success = basedir.mkdir();
			if (success)
				Main.log.info("[CORE] Successfully created contact database!");
			else
			{
				Main.log.info("[CORE] Unable to create contact database. Please contact developers if this persists.");
				JOptionPane.showMessageDialog(null, "Error creating contact database.\nContact developers if this error persists.\n\nError Code 1", "Error", JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	/**
	 * Create the application.
	 */
	public Main() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmChatV = new JFrame();
		frmChatV.setTitle(CHAT_VERSION);
		frmChatV.setBounds(100, 100, 800, 600);
		frmChatV.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmChatV.getContentPane().setLayout(null);
		
		JLabel lblTitle = new JLabel(CHAT_VERSION);
		lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitle.setFont(new Font("Arial", Font.PLAIN, 31));
		lblTitle.setBounds(6, 6, 788, 37);
		frmChatV.getContentPane().add(lblTitle);
		
		JLabel lblInfo = new JLabel("<html><body><p>This is an application that allows you to chat with other people using the same software. All you need is their IP address and UPnP support on your router.</p></body></html>");
		lblInfo.setVerticalAlignment(SwingConstants.TOP);
		lblInfo.setBounds(6, 55, 788, 37);
		frmChatV.getContentPane().add(lblInfo);
		
		JButton btnSendMessage = new JButton("Send Message");
		btnSendMessage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Client.SendMessage();
				} catch (UnknownHostException e1) {
					JOptionPane.showMessageDialog(null, "Unknown Host Error", "Error", JOptionPane.ERROR_MESSAGE);
				} catch (NullPointerException e1) {
					JOptionPane.showMessageDialog(null, "No Message Sent!", "No Message Sent!", JOptionPane.ERROR_MESSAGE);
				} catch (ConnectException e1) {
					JOptionPane.showMessageDialog(null, "Could Not Connect to Remote Server!", "No Message Sent!", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnSendMessage.setBounds(6, 104, 149, 29);
		frmChatV.getContentPane().add(btnSendMessage);
		
		JButton btnGetLocalIp = new JButton("Get Local IP");
		btnGetLocalIp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					IP.getLocalIP();
				} catch (UnknownHostException e1) {
					JOptionPane.showMessageDialog(null, "Unknown Host Error", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnGetLocalIp.setBounds(167, 104, 124, 29);
		frmChatV.getContentPane().add(btnGetLocalIp);
		
		JButton btnGetExternalIp = new JButton("Get External IP");
		btnGetExternalIp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					IP.getExternalIP();
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(null, "Connection Error\nAre you connected to the Internet?", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnGetExternalIp.setBounds(303, 104, 156, 29);
		frmChatV.getContentPane().add(btnGetExternalIp);
		
		chkEnableServer = new JCheckBox("Enable Server");
		chkEnableServer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (chkEnableServer.isSelected())
				{
					server = new Server();
					server.start();
				}
				else
				{
					server.CloseServer();
				}
			}
		});
		chkEnableServer.setBounds(7, 191, 148, 23);
		frmChatV.getContentPane().add(chkEnableServer);
		
		JButton btnManageContacts = new JButton("Manage Contacts");
		btnManageContacts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Contact.launch_window();
			}
		});
		btnManageContacts.setBounds(6, 222, 180, 25);
		frmChatV.getContentPane().add(btnManageContacts);
		
	}
}
